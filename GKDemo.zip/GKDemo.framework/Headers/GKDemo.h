//
//  GKDemo.h
//  GKDemo
//
//  Created by ganesh on 09/01/18.
//  Copyright © 2018 Cidaas. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for GKDemo.
FOUNDATION_EXPORT double GKDemoVersionNumber;

//! Project version string for GKDemo.
FOUNDATION_EXPORT const unsigned char GKDemoVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GKDemo/PublicHeader.h>


